import { Routes } from '@angular/router';
import { LoginComponent } from './authentication/components/login/login.component';
import { RegisterComponent } from './authentication/components/register/register.component';
import { AdminComponent } from './authentication/components/admin/admin.component';
import { authGuard } from './authentication/models/guards/auth.guard';
import { CabServiceComponent } from './authentication/cab-service/cab-service.component';
import { FlightServiceComponent } from './authentication/flight-service/flight-service.component';
import { HotelServiceComponent } from './authentication/hotel-service/hotel-service.component';
import { TourServiceComponent } from './authentication/tour-service/tour-service.component';
import { HomeComponent } from './authentication/home/home.component';
import { DashboardComponent } from './authentication/components/dashboard/dashboard.component';
import { AdminCabDetailsComponent } from './authentication/components/admin-cab-details/admin-cab-details.component';
import { AdminFlightDetailsComponent } from './authentication/components/admin-flight-details/admin-flight-details.component';
import { AdminHotelDetailsComponent } from './authentication/components/admin-hotel-details/admin-hotel-details.component';
import { AdminTourDetailsComponent } from './authentication/components/admin-tour-details/admin-tour-details.component';
import { ServiceProviderDetailsComponent } from './authentication/components/service-provider-details/service-provider-details.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent, canActivate: [authGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },
  { path: 'admin', component: AdminComponent, canActivate: [authGuard] },
  { path: 'cab-service', component: CabServiceComponent, canActivate: [authGuard] },
  { path: 'flight-service', component: FlightServiceComponent, canActivate: [authGuard] },
  { path: 'hotel-service', component: HotelServiceComponent, canActivate: [authGuard] },
  { path: 'tour-service', component: TourServiceComponent, canActivate: [authGuard] },
  { path: 'service-provider-details/:id', component: ServiceProviderDetailsComponent },
  { path: 'admin-cab-details', component: AdminCabDetailsComponent, canActivate: [authGuard] },
  { path: 'admin-hotel-details', component: AdminHotelDetailsComponent, canActivate: [authGuard] },
  { path: 'admin-flight-details', component: AdminFlightDetailsComponent, canActivate: [authGuard] },
  { path: 'admin-tour-details', component: AdminTourDetailsComponent, canActivate: [authGuard] },
  { path: '**', redirectTo: 'login', pathMatch: 'full' }, 
];