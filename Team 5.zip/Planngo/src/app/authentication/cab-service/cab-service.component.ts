import { Component } from '@angular/core';

@Component({
  selector: 'app-cab-service',
  standalone: true,
  imports: [],
  templateUrl: './cab-service.component.html',
  styleUrl: './cab-service.component.css'
})
export class CabServiceComponent {

}
