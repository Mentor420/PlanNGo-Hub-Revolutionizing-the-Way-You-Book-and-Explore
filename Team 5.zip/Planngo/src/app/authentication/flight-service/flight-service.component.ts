import { Component } from '@angular/core';

@Component({
  selector: 'app-flight-service',
  standalone: true,
  imports: [],
  templateUrl: './flight-service.component.html',
  styleUrl: './flight-service.component.css'
})
export class FlightServiceComponent {

}
