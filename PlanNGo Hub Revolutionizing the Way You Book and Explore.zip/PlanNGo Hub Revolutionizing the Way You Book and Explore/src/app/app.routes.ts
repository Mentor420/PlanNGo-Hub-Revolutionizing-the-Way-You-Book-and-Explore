import { Route } from '@angular/router';
import { PlanNGoComponent } from './hotels/components/planngo/planngo.component';

export const routes: Route[] = [
  { path: 'planngo', component: PlanNGoComponent },
];
